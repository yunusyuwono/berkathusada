-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Sep 2022 pada 03.15
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `berkathusada`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `antrian`
--

CREATE TABLE `antrian` (
  `id` int(11) NOT NULL,
  `tgl` date NOT NULL,
  `noantri` int(11) NOT NULL,
  `kodepasien` varchar(30) NOT NULL,
  `poli` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `apotek_chutang`
--

CREATE TABLE `apotek_chutang` (
  `id` int(11) NOT NULL,
  `nofaktur` varchar(30) NOT NULL,
  `bayar` int(11) NOT NULL,
  `entri` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `apotek_trk`
--

CREATE TABLE `apotek_trk` (
  `id` int(11) NOT NULL,
  `nofaktur` varchar(30) NOT NULL,
  `tglfaktur` date NOT NULL,
  `idkasir` varchar(10) NOT NULL,
  `kodepasien` varchar(20) NOT NULL,
  `ppn` varchar(10) NOT NULL,
  `admin` int(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `bayar` int(11) NOT NULL,
  `status_bayar` varchar(20) NOT NULL,
  `entri` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `apotek_trkdetail`
--

CREATE TABLE `apotek_trkdetail` (
  `id` int(11) NOT NULL,
  `faktur` varchar(30) NOT NULL,
  `kode` varchar(30) NOT NULL,
  `jml` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `biaya` int(11) NOT NULL,
  `diskon` int(11) NOT NULL,
  `entri` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `id` int(11) NOT NULL,
  `nofaktur` varchar(30) NOT NULL,
  `kode` varchar(30) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jml` int(11) NOT NULL,
  `jml_klinik` int(11) NOT NULL,
  `jml_apotek` int(11) NOT NULL,
  `ed` date NOT NULL,
  `hargabeli` int(11) NOT NULL,
  `hargajual` int(11) NOT NULL,
  `satuan` varchar(30) NOT NULL,
  `diskon` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  `entri` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`id`, `nofaktur`, `kode`, `nama`, `jml`, `jml_klinik`, `jml_apotek`, `ed`, `hargabeli`, `hargajual`, `satuan`, `diskon`, `status`, `entri`) VALUES
(1, '123', 'TLKANGINS', 'TOLAK ANGIN SACHET', 2, 0, 3, '2024-10-17', 50000, 70000, 'kotak', 0, 'STOK', '2022-07-31 01:18:08');

-- --------------------------------------------------------

--
-- Struktur dari tabel `barangdist`
--

CREATE TABLE `barangdist` (
  `id` int(11) NOT NULL,
  `idbrg` varchar(30) NOT NULL,
  `dari` varchar(20) NOT NULL,
  `ke` varchar(20) NOT NULL,
  `jml` int(11) NOT NULL,
  `entri` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `barangdist`
--

INSERT INTO `barangdist` (`id`, `idbrg`, `dari`, `ke`, `jml`, `entri`) VALUES
(1, '1', 'center', 'apotek', 3, '2022-07-30 17:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `barangmasuk`
--

CREATE TABLE `barangmasuk` (
  `id` int(11) NOT NULL,
  `tgl_faktur` date NOT NULL,
  `tgl_dtg` date NOT NULL,
  `iddist` varchar(10) NOT NULL,
  `nofaktur` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL,
  `entri` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `barangmasuk`
--

INSERT INTO `barangmasuk` (`id`, `tgl_faktur`, `tgl_dtg`, `iddist`, `nofaktur`, `status`, `entri`) VALUES
(1, '2022-07-29', '2022-07-30', '1', '123', 'D', '2022-07-30 15:59:28');

-- --------------------------------------------------------

--
-- Struktur dari tabel `distributor`
--

CREATE TABLE `distributor` (
  `id` int(11) NOT NULL,
  `kode` varchar(30) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `hp` varchar(20) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `distributor`
--

INSERT INTO `distributor` (`id`, `kode`, `nama`, `hp`, `alamat`) VALUES
(1, 'D001', 'PT.Sidomuncul', '0', 'jl2');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jasa`
--

CREATE TABLE `jasa` (
  `id` int(11) NOT NULL,
  `kode` varchar(30) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `harga` int(11) NOT NULL,
  `entri` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `klinik_chutang`
--

CREATE TABLE `klinik_chutang` (
  `id` int(11) NOT NULL,
  `nofaktur` varchar(30) NOT NULL,
  `bayar` int(11) NOT NULL,
  `entri` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `klinik_trk`
--

CREATE TABLE `klinik_trk` (
  `id` int(11) NOT NULL,
  `nofaktur` varchar(30) NOT NULL,
  `tglfaktur` date NOT NULL,
  `idkasir` varchar(10) NOT NULL,
  `kodepasien` varchar(20) NOT NULL,
  `ppn` varchar(10) NOT NULL,
  `admin` int(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `bayar` int(11) NOT NULL,
  `status_bayar` varchar(20) NOT NULL,
  `entri` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `klinik_trk`
--

INSERT INTO `klinik_trk` (`id`, `nofaktur`, `tglfaktur`, `idkasir`, `kodepasien`, `ppn`, `admin`, `status`, `bayar`, `status_bayar`, `entri`) VALUES
(1, 'TBH202200001', '2022-08-13', '', '', '', 0, 'proses', 0, '', '2022-08-13 06:53:33');

-- --------------------------------------------------------

--
-- Struktur dari tabel `klinik_trkdetail`
--

CREATE TABLE `klinik_trkdetail` (
  `id` int(11) NOT NULL,
  `faktur` varchar(30) NOT NULL,
  `kode` varchar(30) NOT NULL,
  `jml` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `biaya` int(11) NOT NULL,
  `diskon` int(11) NOT NULL,
  `entri` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pasien`
--

CREATE TABLE `pasien` (
  `id` int(11) NOT NULL,
  `kodepasien` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id` int(11) NOT NULL,
  `kode` varchar(20) NOT NULL,
  `nik` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jk` varchar(10) NOT NULL,
  `hp` varchar(20) NOT NULL,
  `tmpl` varchar(30) NOT NULL,
  `tgll` date NOT NULL,
  `alamat` text NOT NULL,
  `entri` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `poli`
--

CREATE TABLE `poli` (
  `id` int(11) NOT NULL,
  `poli` varchar(40) NOT NULL,
  `iddokter` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `riwayat`
--

CREATE TABLE `riwayat` (
  `id` int(11) NOT NULL,
  `kode` varchar(20) NOT NULL,
  `idpasien` int(11) NOT NULL,
  `iddokter` int(11) NOT NULL,
  `tgl` date NOT NULL,
  `anamnesa` text NOT NULL,
  `diagnosis` text NOT NULL,
  `terapi` text NOT NULL,
  `entri` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `satuan`
--

CREATE TABLE `satuan` (
  `id` int(11) NOT NULL,
  `satuan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `satuan`
--

INSERT INTO `satuan` (`id`, `satuan`) VALUES
(1, 'keping'),
(2, 'botol'),
(3, 'lusin'),
(4, 'tablet'),
(5, 'pcs'),
(6, 'kotak');

-- --------------------------------------------------------

--
-- Struktur dari tabel `so_cek`
--

CREATE TABLE `so_cek` (
  `id` int(11) NOT NULL,
  `kode` varchar(20) NOT NULL,
  `kodebarang` varchar(20) NOT NULL,
  `stokreal` int(11) NOT NULL,
  `ket` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `so_cek`
--

INSERT INTO `so_cek` (`id`, `kode`, `kodebarang`, `stokreal`, `ket`) VALUES
(1, '22080201', 'TLKANGINS', 0, '0');

-- --------------------------------------------------------

--
-- Struktur dari tabel `so_master`
--

CREATE TABLE `so_master` (
  `id` int(11) NOT NULL,
  `kode` varchar(30) NOT NULL,
  `tgl1` date NOT NULL,
  `tgl2` date NOT NULL,
  `lokasi` varchar(20) NOT NULL,
  `entri` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `so_master`
--

INSERT INTO `so_master` (`id`, `kode`, `tgl1`, `tgl2`, `lokasi`, `entri`) VALUES
(1, '22080201', '2022-08-13', '2022-08-14', 'Apotek', '2022-08-13 07:03:30'),
(2, '22080102', '2022-08-13', '2022-08-13', 'Gudang/Centre', '2022-08-13 07:04:37');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tindakan`
--

CREATE TABLE `tindakan` (
  `id` int(11) NOT NULL,
  `kode` varchar(30) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `harga` int(11) NOT NULL,
  `entri` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `kode` varchar(20) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `gelar1` varchar(20) NOT NULL,
  `gelar2` varchar(20) NOT NULL,
  `tgll` date NOT NULL,
  `nohp` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pas` varchar(60) NOT NULL,
  `status` varchar(50) NOT NULL,
  `entri` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `kode`, `nama`, `gelar1`, `gelar2`, `tgll`, `nohp`, `email`, `pas`, `status`, `entri`) VALUES
(1, 'K9999999', 'ADMIN CENTER', '', '', '0000-00-00', '082183925322', 'admincenter@berkathusadakaur.com', '6051e9bdf8241b9e6b9b240539446334', 'Admin Center,Apotek,Klinik,Dokter', '2022-04-15 08:58:17'),
(4, 'K2281004', 'Wendra', 'dr', '', '1981-01-31', '1234', 'daeda@dwa.ca', '81dc9bdb52d04dc20036dbd8313ed055', 'Klinik,Dokter', '2022-04-15 09:23:11'),
(5, 'K2293005', 'Afryandri C', '', 'S.Kom', '1993-01-01', '321', 'aan@chan.com', 'caf1a3dfb505ffed0d024130f58c5cfa', '', '2022-04-15 04:19:40');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_akses`
--

CREATE TABLE `user_akses` (
  `id` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `akses` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `antrian`
--
ALTER TABLE `antrian`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `apotek_chutang`
--
ALTER TABLE `apotek_chutang`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `apotek_trk`
--
ALTER TABLE `apotek_trk`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `apotek_trkdetail`
--
ALTER TABLE `apotek_trkdetail`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `barangdist`
--
ALTER TABLE `barangdist`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `barangmasuk`
--
ALTER TABLE `barangmasuk`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `distributor`
--
ALTER TABLE `distributor`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `jasa`
--
ALTER TABLE `jasa`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `klinik_chutang`
--
ALTER TABLE `klinik_chutang`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `klinik_trk`
--
ALTER TABLE `klinik_trk`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `klinik_trkdetail`
--
ALTER TABLE `klinik_trkdetail`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `poli`
--
ALTER TABLE `poli`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `riwayat`
--
ALTER TABLE `riwayat`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `satuan`
--
ALTER TABLE `satuan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `so_cek`
--
ALTER TABLE `so_cek`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `so_master`
--
ALTER TABLE `so_master`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tindakan`
--
ALTER TABLE `tindakan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `antrian`
--
ALTER TABLE `antrian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `apotek_chutang`
--
ALTER TABLE `apotek_chutang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `apotek_trk`
--
ALTER TABLE `apotek_trk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `apotek_trkdetail`
--
ALTER TABLE `apotek_trkdetail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `barang`
--
ALTER TABLE `barang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `barangdist`
--
ALTER TABLE `barangdist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `barangmasuk`
--
ALTER TABLE `barangmasuk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `distributor`
--
ALTER TABLE `distributor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `jasa`
--
ALTER TABLE `jasa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `klinik_chutang`
--
ALTER TABLE `klinik_chutang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `klinik_trk`
--
ALTER TABLE `klinik_trk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `klinik_trkdetail`
--
ALTER TABLE `klinik_trkdetail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pasien`
--
ALTER TABLE `pasien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `poli`
--
ALTER TABLE `poli`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `riwayat`
--
ALTER TABLE `riwayat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `satuan`
--
ALTER TABLE `satuan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `so_cek`
--
ALTER TABLE `so_cek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `so_master`
--
ALTER TABLE `so_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tindakan`
--
ALTER TABLE `tindakan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
