<?php 
include 'nav.php';
?>
<div id="main">
    <header class="">
        <a href="#" class="burger-btn d-block p-2">
            <i class="fas fa-bars"></i> Menu 
        </a>
    </header> 
    <div class="page-content">
        <section class="row">
            <div class="col-12">
                <div class="card card-body text-dark">
                Selamat Datang Admin Center Klinik & Apotek Berkat Husada
                </div>
            </div>
            <div class="col-6 col-lg-4">
                <div class="card">
                    <div class="card-body px-3 py-4-5">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="text-primary">
                                    <i style="font-size:36pt" class="fas fa-exchange-alt"></i>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <h6 class="text-muted font-semibold">Transaksi Hari Ini</h6>
                                <h4 class="font-extrabold mb-0"></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-6 col-lg-4">
                <div class="card">
                    <div class="card-body px-3 py-4-5">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="text-primary">
                                    <i style="font-size:36pt" class="fas fa-exchange-alt"></i>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <h6 class="text-muted font-semibold">Transaksi Bulan Ini</h6>
                                <h4 class="font-extrabold mb-0"></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-6 col-lg-4">
                <div class="card">
                    <div class="card-body px-3 py-4-5">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="text-primary">
                                    <i style="font-size:36pt" class="fas fa-exchange-alt"></i>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <h6 class="text-muted font-semibold">Transaksi Piutang</h6>
                                <h4 class="font-extrabold mb-0"></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-8">
                <div class="card">
                    <div class="card-body px-3 py-4-5">
                        <div class="row">
                            <div class="col-md-12">
                                <h6 class="text-muted font-semibold">Barang akan kadaluarsa</h6>
                                <div class="table table-responsive">
                                    <table class="table table-striped table-hover table-borderless">
                                        <thead>
                                            <th>No.</th>
                                            <th>Kode</th>
                                            <th>Nama</th>
                                            <th>Stok</th>
                                            <th>ED</th>
                                        </thead>

                                        <tfoot>
                                            <td colspan="5">
                                                <a href="barang?hal=baranged" class="btn btn-sm btn-primary"><i class="fas fa-database"></i> Lihat semua</a>
                                            </td>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body px-3 py-4-5">
                        <h6 class="text-muted font-semibold">Grafik Transaksi per bulan</h6>
                    </div>
                </div>
            </div>

            <div class="col-12 col-lg-4">
                <div class="card">
                    <div class="card-body px-3 py-4-5">
                        <h6 class="text-muted font-semibold">Barang terlaris</h6>
                        <ol class="list-group">
                            <li class="list-group-item"></li>
                        </ol>
                    </div>
                </div>
            </div>                
            </div>        
        </section>
    </div>
</div>

<?php include 'foot.php';?>