<?php 
$kon=mysqli_connect("localhost","root","","berkathusada");
?>